export default {
    apiKey: "AIzaSyCOgIFbiA2Q88iDsq45w-TBNaRJ7vl-p3Y",
    authDomain: "gamingnesia-dc59a.firebaseapp.com",
    databaseURL: "https://gamingnesia-dc59a.firebaseio.com",
    projectId: "gamingnesia-dc59a",
    storageBucket: "gamingnesia-dc59a.appspot.com",
    messagingSenderId: "327389511073",
    appId: "1:327389511073:web:79345dc545930e10359fe0",
    measurementId: "G-YNDRRGE2RL"
  }