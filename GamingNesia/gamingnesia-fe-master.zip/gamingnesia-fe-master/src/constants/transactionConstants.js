
export const WAITING_FOR_ADMIN_CONFIRMATION = 0
export const WAITING_FOR_BUYER_CONFIRMATION = 1
export const COMPLETED = 2
export const FAILED = 3