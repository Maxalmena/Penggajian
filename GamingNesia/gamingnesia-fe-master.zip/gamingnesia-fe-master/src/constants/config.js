export const API_URL = process.env.VUE_APP_API_URL
export const BANNER_IMAGE = 'BANNER_IMAGE'
export const BASIC_ADMIN_FEE = 'BASIC_ADMIN_FEE'
export const VIP_ADMIN_FEE = 'VIP_ADMIN_FEE'
