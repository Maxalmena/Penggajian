# gamingnesia-fe
 
To run this project you need

*Latest Stable Node Version*
 
 
### Installation
---

Install node deps in root folder.
```
npm install
```

### Usage
---
##### Development
```
npm run dev
```

To rebuild Tailwind CSS after changing some preferences
```
npm run build:css
```


##### Production
```
npm run build
```
