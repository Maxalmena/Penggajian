package com.warungsoftware.domain.exceptions

class InvalidRequestException(msg: String) : Exception(msg)