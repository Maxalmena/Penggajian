package com.warungsoftware.domain.exceptions

class AuthorizationException(msg: String) : Exception(msg)