package com.warungsoftware.domain.exceptions

class AuthenticationException(msg: String) : Exception(msg)