package com.warungsoftware.domain.exceptions

class NotFoundException(msg: String) : Exception(msg)