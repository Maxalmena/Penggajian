Cara Install
1. install Xampp
2. copy folder ksp ke C:\xampp\htdocs\ksp
3. buka chrome/firefox ketik localhost/phpmyadmin
4. pada kolom create new database ketikkan "ksp" klik create
5. klik "import", klik "Choose File" arahkan ke "C:\xampp\htdocs\ksp" pilih "ksp.sql" lalu klik "Go"
6. buka tab baru ketikkan "localhost/ksp"
7. user dan password default username:admin, password:admin

