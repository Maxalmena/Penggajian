<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">My Profile</h3>
        <br>
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body text-center">
                    <p>
                        <img src="<?php echo e(Storage::url($user->profile_picture)); ?>" width="150px" alt="My Profile Picture">
                    </p>
                    <p>Fullname: <?php echo e($user->name); ?></p>
                    <p>Email Address: <?php echo e($user->email); ?></p>
                    <p>Phone Number: <?php echo e($user->phone_number); ?></p>
                    <p>Gender: <?php echo e($user->gender); ?></p>
                    <p>Address: <?php echo e($user->address); ?></p> 
                    <a href="<?php echo e(route('edit_my_profile')); ?>" class="btn btn-primary">Edit My Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>