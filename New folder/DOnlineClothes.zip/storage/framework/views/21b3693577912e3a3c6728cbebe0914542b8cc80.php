<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/AdminLTE.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/_all-skins.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('node_modules/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/rating.css')); ?>" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="box">
                <div class="box-header">
                    <h3>Chat</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div style="background-color: #4b646f;padding: 10px 10px 10px 10px; border-top: 0px;height: 700px" class="box">
                                <?php $__currentLoopData = $chatt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->active == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                        <div style="background-color: #cbb956; margin: 0" onclick="show(<?php echo e($c->id); ?>)" id="warna<?php echo e($c->id); ?>" class="row">
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($c->user_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                                    <?php if($c->seller_id == $u->id): ?>
                                                        <div style="padding-left: 0" class="col-md-8">
                                                            <h3 style="margin-left: 15px"><?php echo e($u->name); ?></h3>
                                                        </div>
                                                        <div style="margin-top: 10px" id="index<?php echo e($c->id); ?>" class="col-md-4 text-right">
                                                            <span style="font-size: 30px;"><?php echo e($c->user_active); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($c->user_id == $u->id): ?>
                                                        <div style="padding-left: 0" class="col-md-8">
                                                            <h3 style="margin-left: 15px"><?php echo e($u->name); ?></h3>
                                                        </div>
                                                        <div style="margin-top: 10px" id="index<?php echo e($c->id); ?>" class="col-md-4 text-right">
                                                            <span style="font-size: 30px;"><?php echo e($c->seller_active); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <div style="background-color: white;margin: 0" onclick="show(<?php echo e($c->id); ?>)" class="row">
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($c->user_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                                    <?php if($c->seller_id == $u->id): ?>
                                                        <h3 style="margin-left: 15px"><?php echo e($u->name); ?></h3>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($c->user_id == $u->id): ?>
                                                        <h3 style="margin-left: 15px"><?php echo e($u->name); ?></h3>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div style="background-color: #4b646f; padding: 10px 10px 10px 10px;border-top: 0px;height: 700px" id="chat-box" class="box">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function show(id) {
            $("#chat-box").load("/chat_detail/"+id);
            $("#warna" + id).css("background-color", "white");
            $("#index" + id).hide();
        }
    </script>
</body>
</html>
