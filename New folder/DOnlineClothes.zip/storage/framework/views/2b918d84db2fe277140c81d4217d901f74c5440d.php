<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Transaction History</h3>
        <br>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <p>Transaction ID: <?php echo e($transaction->id); ?></p>
            <p>User's Name: <?php echo e($transaction->user->name); ?></p>
            <p>Transaction Date: <?php echo e($transaction->transaction_date); ?></p>
        </div>
        <table class="table table-hover">
            <thead>
                <th>Picture</th>
                <th>Clothes Name</th>
                <th>Quantity</th>
                <th>Price</th>
            </thead>

            <?php $__currentLoopData = $transaction->detailTransactions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <td><img src="<?php echo e(Storage::url($detail_transaction->product->image)); ?>" width="100px" alt="Product Image"></td>
                <td><?php echo e($detail_transaction->product->name); ?></td>
                <td><?php echo e($detail_transaction->quantity); ?></td>
                <td><?php echo e($detail_transaction->product->price); ?></td>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <div>
            <p>Total Price (Before Discount): <?php echo e($transaction->total_amount_before_discount); ?></p>
            <p>Promo: <?php echo e(($transaction->promo != null) ? $transaction->promo->name : '-'); ?></p>
            <p>Discount: <?php echo e(($transaction->promo != null) ? $transaction->promo->name : 0); ?></p>
            <p>Total Price (After Discount): <?php echo e($transaction->total_amount_after_discount); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>