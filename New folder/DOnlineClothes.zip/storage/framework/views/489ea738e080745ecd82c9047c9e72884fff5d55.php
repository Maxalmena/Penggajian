<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="box">
            <div class="box-header">
                <h3 class="text-center">Transaction History</h3>
            </div>
            <div class="box-body">
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box">
                        <div class="box-header">
                            <div>
                                <p>Transaction ID: <?php echo e($transaction->id); ?></p>
                                <p>User's Name: <?php echo e($transaction->user->name); ?></p>
                                <p>Transaction Date: <?php echo e($transaction->transaction_date); ?></p>
                            </div>
                        </div>
                        <div class="box-body">
                            <table class="table table-hover">
                                <thead>
                                    <th>Picture</th>
                                    <th>Clothes Name</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </thead>

                                <?php $__currentLoopData = $transaction->detailTransactions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <td><img src="<?php echo e(url('/image/'.$detail_transaction->product->image)); ?>" width="100px" alt="Product Image"></td>
                                    <td><?php echo e($detail_transaction->product->name); ?></td>
                                    <td><?php echo e($detail_transaction->quantity); ?></td>
                                    <td><?php echo e($detail_transaction->product->price); ?></td>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                        <div class="box-footer">
                            <div>
                                <p>Total Price (Before Discount): <?php echo e($transaction->total_amount_before_discount); ?></p>
                                <p>Promo: <?php echo e(($transaction->promo != null) ? $transaction->promo->name : '-'); ?></p>
                                <p>Discount: <?php echo e(($transaction->promo != null) ? $transaction->promo->name : 0); ?></p>
                                <p>Fee: <?php echo e($transaction->total_amount_plus_fee -  $transaction->total_amount_after_discount); ?></p>
                                <p>Total Price (After Discount): <?php echo e($transaction->total_amount_after_discount); ?></p>
                                <p>Total Price (After Discount & Plus Fee): <?php echo e($transaction->total_amount_plus_fee); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>