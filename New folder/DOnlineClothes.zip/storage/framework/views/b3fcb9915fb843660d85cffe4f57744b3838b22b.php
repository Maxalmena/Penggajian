<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Manage Clothes</h3>
        <br>
        <div class="text-center">
            <a href="<?php echo e(route('add_product_page')); ?>" class="btn btn-primary">Add New Clothes</a>
        </div>
        <br>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="thumbnail">
                <div class="text-center">
                    <p><img src="<?php echo e(Storage::url($product->image)); ?>" width="150px" alt="Product Image"></p>
                    <h5>Name: <?php echo e($product->name); ?></h5>
                    <p>Category: <?php echo e($product->category->name); ?></p>
                    <p>Price: <?php echo e($product->price); ?></p>
                    <p>Stock: <?php echo e($product->stock); ?></p>
                    <p>Description: <?php echo e($product->description); ?></p>

                    <?php if(Auth::user()['role'] == 'Admin'): ?>
                    <a href="<?php echo e(route('edit_product', $product)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('delete_product', $product)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>


                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="text-center"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>