<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="box">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('add_promo')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="box-header">
                    <h3 class="text-center">Insert Promo</h3>
                </div>
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Promo Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                            <label for="type" class="col-md-4 control-label">Promo Type</label>

                            <div class="col-md-6">
                                <select name="type" id="type" style="width: 100%">
                                    <option value="nom">Nominal</option>
                                    <option value="persen">Persen</option>
                                </select>

                                <?php if($errors->has('type')): ?>
                                    <span class="help-block">
                                    <strong><?php echo e($errors->first('type')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                            <label for="code" class="col-md-4 control-label">Promo Code</label>

                            <div class="col-md-6">
                                <input id="code" type="text" class="form-control" name="code" value="<?php echo e(old('code')); ?>">

                                <?php if($errors->has('code')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('code')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('promo_discount') ? ' has-error' : ''); ?>">
                            <label for="promo_discount" class="col-md-4 control-label">Promo Discount</label>

                            <div class="col-md-6">
                                <input id="promo_discount" type="text" class="form-control" name="promo_discount" value="<?php echo e(old('promo_discount')); ?>">

                                <?php if($errors->has('promo_discount')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('promo_discount')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('end_date') ? ' has-error' : ''); ?>">
                            <label for="start_date" class="col-md-4 control-label">Start Date</label>

                            <div class="col-md-6">
                                <input id="start_date" type="date" class="form-control" name="start_date" value="<?php echo e(old('start_date')); ?>">

                                <?php if($errors->has('start_date')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('start_date')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('end_date') ? ' has-error' : ''); ?>">
                            <label for="end_date" class="col-md-4 control-label">End Date</label>

                            <div class="col-md-6">
                                <input id="end_date" type="date" class="form-control" name="end_date" value="<?php echo e(old('end_date')); ?>">

                                <?php if($errors->has('end_date')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('end_date')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer text-right">
                    <div class="form-group">
                        <div class="col-md-12 ">
                            <button type="submit" class="btn btn-primary">
                                Insert Promo
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>