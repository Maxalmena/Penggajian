<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="box">
            <div style="padding-bottom: 35px" class="row">
                <h3 class="text-center">Games</h3>
                <br>
                <div class="col-md-12">
                    <form action="<?php echo e(route('search_product')); ?>" method="POST" style="margin-right: 10px;margin-left: 10px">
                        <?php echo e(csrf_field()); ?>

                        <div class="input-group">
                            <input type="text" name="search_string" id="search_string" placeholder="Search"
                                class="form-control">
                            <div class="input-group-btn">
                                <input type="submit" name="search_button" id="search_button" value="Search" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="box">
            <div class="box-header">
                <h3>Products</h3>
            </div>
            <div class="box-body">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 ">
                        <div class="thumbnail">
                            <div class="text-center">
                                <div class="row">
                                    <div style="margin-top: 5px" class="row text-center">
                                        <p><a href="image/<?php echo e($product->image); ?>" ><img src="image/<?php echo e($product->image); ?>" style="height: 180px"  alt="Product Image"></a></p>
                                    </div>
                                    <div style="margin-left: 40px" class="row">
                                        <h4 style="padding-top: 0" class="text-left">Name: <?php echo e($product->name); ?></h4>
                                        <p class="text-left">Price: <?php echo e($product->price); ?></p>
                                        <p  class="text-left">Category: <?php echo e($product->cate); ?></p>
                                        <p class="text-left">Seller: <?php echo e($product->nama); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div style="padding-bottom: 10px" class="row">
                                <div style="padding: 0;margin-right: 5px" class="col-md-6 text-right">
                                    <a href="/view_detail/<?php echo e($product->id); ?>"><button type="submit" class="btn btn-primary">View Detail</button></a>
                                </div>
                                <div style="padding: 0;margin-left: 5px" class="col-md-5">
                                    <a href="/add_chat/<?php echo e($product->id); ?>"><button type="submit" class="btn btn-primary">Chat</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<div class="text-center"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>