<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="box">
            <form action="<?php echo e(route('add_to_cart', $pro->id)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="box-header">
                <h3>Product Detail</h3>
            </div>
                <div class="box-body">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(url('/image/'.$pro->image)); ?>" height="300px">
                        </div>
                        <div style="padding: 0" class="col-md-6">
                            <div class="row">
                                <h2 style="margin: 0"><?php echo e($pro->name); ?> - <?php echo e($pro->cate); ?></h2>
                            </div>
                            <div style="margin-top: 10px" class="row">
                                <div style="padding: 0;font-size: 20px" class="col-md-12">
                                    <?php if($pro->type == 1): ?>
                                        <p>Currency</p>
                                    <?php elseif($pro->type == 2): ?>
                                        <p>Item & Skin</p>
                                    <?php endif; ?>
                                    <p>Price : <?php echo e($pro->price); ?></p>
                                    <p>Min. Pembelian : <?php echo e($pro->stock); ?></p>
                                    <p>Stock Product : <?php echo e($pro->totaunit); ?></p>
                                    <p>Delivery Guarantee : <?php echo e($pro->delivery); ?></p>
                                    <p>Jumlah : <input type="number" name="quan" value="<?php echo e($pro->stock); ?>"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="font-size: 20px;margin-left: 0;margin-top: 15px" class="row">
                        <div class="tab-v1">
                            <ul class="nav nav-tabs">
                                <li><a href="#description" data-toggle="tab">Description</a></li>
                                <li><a href="#ulasan" data-toggle="tab">Ulasan</a></li>
                                <li><a href="#rating" data-toggle="tab">Rating</a></li>
                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="description">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <p style="margin-left: 5px;margin-top: 15px"><?php echo e($pro->description); ?>

                                            </p>
                                        </div>

                                    </div>
                                </div>
                                <div class="tab-pane fade in disabled" id="ulasan">
                                    <div class="row">
                                        <div style="margin-left: 15px;margin-top: 10px" class="row">
                                            <?php if($ulasan != null): ?>
                                            <?php $__currentLoopData = $ulasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div style="max-width: 97%;" class="box">
                                                    <div style="padding: 0" class="box-header">
                                                        <p style="margin-left: 10px"><?php echo e($ul->name); ?></p>
                                                    </div>
                                                    <div style="padding: 0" class="box-body">
                                                        <div style="padding: 0" class="col-md-3">
                                                            <img style="margin-left: 10px;" width="150px" src="<?php echo e(url('/image/'.$ul->profile_picture)); ?>">
                                                        </div>
                                                        <div style="padding: 0" class="col-md-9">
                                                            <p><?php echo e($ul->ulasan); ?></p>
                                                        </div>
                                                    </div>
                                                    <div style="padding: 0" class="box-footer text-right">
                                                        <p><?php echo e($ul->date); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div style="max-width: 97%;" class="box">
                                                    <div style="padding: 0" class="box-header">
                                                        <p style="margin-left: 10px">Tidak ada Ulasan</p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade in disabled" id="rating">
                                    <div class="col-md-3">
                                        <div style="margin-top: 10px;margin-bottom: 10px" class="box">
                                            <div style="padding: 0px 0px 15px 0px" class="box-body">
                                                <div class="row text-center">
                                                    <h1><?php echo e(number_format($ratetotal,1,'.',',')); ?></h1>
                                                </div>
                                                <div class="row text-center">
                                                    <?php if($ratetotal > 4.5): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                    <?php elseif($ratetotal > 4): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Half-Full.png')); ?>">
                                                    <?php elseif($ratetotal > 3.5): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 3): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Half-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 2.5): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 2): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Half-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 1.5): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 1): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Half-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 0.5): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal > 0): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/Star-Half-Full.png')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php elseif($ratetotal == 0): ?>
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                        <img height="30px" src="<?php echo e(url('/rating/star-kosong.jpg')); ?>">
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div style="margin-top: 10px" class="box">
                                            <div class="box-header">
                                                <h2>Reviewer : <?php echo e($temp); ?></h2>
                                            </div>
                                            <div class="box-body">
                                                <?php
                                                    $rate5 = 0;
                                                    $rate4 = 0;
                                                    $rate3 = 0;
                                                    $rate2 = 0;
                                                    $rate1 = 0;
                                                    $rate0 = 0;
                                                    foreach ($rating as $ra){
                                                        if($ra->rating == 5) $rate5 +=1;
                                                        elseif ($ra->rating == 4) $rate4 +=1;
                                                        elseif ($ra->rating == 3) $rate3 +=1;
                                                        elseif ($ra->rating == 2) $rate2 +=1;
                                                        elseif ($ra->rating == 1) $rate1 +=1;
                                                        elseif ($ra->rating == 0) $rate0 +=1;
                                                    }
                                                ?>
                                                <p>5<img height="15px" src="<?php echo e(url('/rating/Star-Full.png')); ?>"> = <?php echo e($rate5); ?></p>
                                                <p>4<img height="15px" src="<?php echo e(url('/rating/Star-Full.png')); ?>"> = <?php echo e($rate4); ?></p>
                                                <p>3<img height="15px" src="<?php echo e(url('/rating/Star-Full.png')); ?>"> = <?php echo e($rate3); ?></p>
                                                <p>2<img height="15px" src="<?php echo e(url('/rating/Star-Full.png')); ?>"> = <?php echo e($rate2); ?></p>
                                                <p>1<img height="15px" src="<?php echo e(url('/rating/Star-Full.png')); ?>"> = <?php echo e($rate1); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <div class="box-footer">
                <div class="text-right">
                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>