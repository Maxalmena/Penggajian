<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="box">
                <form class="form-horizontal" method="POST" action="/chat_add/<?php echo e($pro->id); ?>/<?php echo e($pro->user_id); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="box-header">
                    <h3>Add Chat</h3>
                </div>
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-4">
                                <img height="200px" src="<?php echo e(url('image/'.$pro->image)); ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label for="name">To</label>
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e($pro->na); ?>" readonly="true">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label for="name" >Message</label>
                                    <textarea id="name" class="form-control" name="name"></textarea>

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer text-right">
                    <div class="form-group">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary">
                                Sent
                            </button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>