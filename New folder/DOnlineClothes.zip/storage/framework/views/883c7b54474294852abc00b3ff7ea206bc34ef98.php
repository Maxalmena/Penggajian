<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Edit Clothes</h3>
        <br>
        <div class="col-md-12">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('update_product', $product)); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 control-label">Clothes Name</label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e($product->name); ?>">

                        <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                    <label for="category" class="col-md-4 control-label">Clothes Category</label>

                    <div class="col-md-6">
                        <select name="category" id="category">
                            <option value="-1">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category->id == $category->id): ?>
                            <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php if($errors->has('category')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('category')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                    <label for="price" class="col-md-4 control-label">Price</label>

                    <div class="col-md-6">
                        <input id="price" type="text" class="form-control" name="price" value="<?php echo e($product->price); ?>">

                        <?php if($errors->has('price')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('price')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="description" class="col-md-4 control-label">Description</label>

                    <div class="col-md-6">
                        <textarea name="description" id="description" cols="35" rows="5"><?php echo e($product->description); ?></textarea>

                        <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('stock') ? ' has-error' : ''); ?>">
                    <label for="stock" class="col-md-4 control-label">Stock</label>

                    <div class="col-md-6">
                        <input type="text" class="form-control" name="stock" id="stock" value="<?php echo e($product->stock); ?>">

                        <?php if($errors->has('stock')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('stock')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                    <label for="image" class="col-md-4 control-label">Clothes Image</label>

                    <div class="col-md-6">
                        <input type="file" name="image" id="image">

                        <?php if($errors->has('image')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('image')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary">
                            Update Clothes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>