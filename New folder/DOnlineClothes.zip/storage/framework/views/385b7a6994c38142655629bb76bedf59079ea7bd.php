<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Manage Promo</h3>
        <br>
        <div class="text-center">
            <a href="<?php echo e(route('add_promo_page')); ?>" class="btn btn-primary">Insert New Promo</a>
        </div>
        <br>
        <div class="col-md-12">
            <table class="table table-hover">
                <thead>
                    <th>Promo Code</th>
                    <th>Promo Name</th>
                    <th>Promo Discount</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Action</th>
                </thead>
                
                <?php $__currentLoopData = $promoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <td><?php echo e($promo->code); ?></td>
                    <td><?php echo e($promo->name); ?></td>
                    <td><?php echo e($promo->promo_discount); ?></td>
                    <td><?php echo e($promo->start_date); ?></td>
                    <td><?php echo e($promo->end_date); ?></td>
                    <td>
                        <a href="<?php echo e(route('edit_promo', $promo)); ?>" class="btn btn-primary">Edit</a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('delete_promo', $promo)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>


                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>