<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="box">
            <div class="box-header">
                <h3 class="text-center">Manage User</h3>
            </div>
            <div class="box-body">
            <div class="col-md-12">
                <table class="table table-hover">
                    <thead>
                        <th>Profile Picture</th>
                        <th>Fullname</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Action</th>
                    </thead>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <td><img src="<?php echo e(url('/image/'.$user->profile_picture)); ?>" alt="User Profile Picture" width="150px"></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone_number); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td>
                            <div style="padding: 0" class="col-md-6">
                                <a href="<?php echo e(route('user_profile', $user)); ?>" class="btn btn-primary">Update</a>
                            </div>
                            <div style="padding: 0;" class="col-md-6">
                                <form action="<?php echo e(route('delete_user', $user)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        </div>
    </div>
</div>

<div class="text-center"><?php echo e($users->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>