<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Cart</h3>
        <br>
        <div class="col-md-12">
        <?php if(!empty($cart)): ?>
            <table class="table table-hover">
                <thead>
                    <th>Picture</th>
                    <th>Clothes Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Action</th>
                </thead>

                <?php $__currentLoopData = $cart['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <td><img src="<?php echo e(Storage::url($item['image'])); ?>" width="150px" alt="Product Image"></td>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td>IDR <?php echo e($item['price']); ?></td>
                    <td>
                        <form action="<?php echo e(route('delete_item_on_cart', $index)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            <form action="<?php echo e(route('checkout')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>


                <div class="col-md-offset-8">
                    <div class="form-group<?php echo e($errors->has('code') ? ' has-error': ''); ?>">
                        <label for="code" class="control-label">Promo Code: </label>
                        <input type="text" name="code" id="code" class="form-control" placeholder="Enter Promo Code">

                        <?php if($errors->has('code')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('code')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-offset-8">
                    <div class="form-group">
                        <label for="code" class="control-label">Total Amount: </label>
                        <p>IDR <?php echo e($cart['total_amount']); ?></p>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-offset-8">
                        <button type="submit" class="btn btn-primary">
                            Checkout
                        </button>
                    </div>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>