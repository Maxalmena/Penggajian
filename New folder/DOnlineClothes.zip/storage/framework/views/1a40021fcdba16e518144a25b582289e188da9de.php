<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/AdminLTE.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/_all-skins.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('node_modules/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/rating.css')); ?>" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div style="background-color: white;margin: auto" class="row">
        <h2 style="padding-left: 10px"><?php echo e($user->name); ?></h2>
    </div>
    <div style="background-color: white;margin: auto;height: 585px;display: block;overflow-y: scroll" class="row">
        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($d->struktur == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                <div style="margin: auto;padding-left: 10px" class="row text-left">
                    <div style="width: 50%" class="box">
                        <div class="box-header">
                            <?php if($d->product_id == 0): ?>
                                <p><?php echo e($d->chat); ?></p>
                            <?php else: ?>
                                <p><img width="150px" src="<?php echo e(url('/image/'.$d->product_id)); ?>" alt=""></p>
                                <p><?php echo e($d->chat); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="box-footer text-right">
                            <p><?php echo e($d->date); ?></p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div style="margin: auto;padding-left: 52%" class="row text-right">
                    <div style="width: 97%" class="box">
                        <div class="box-header">
                            <?php if($d->product_id == 0): ?>
                                <p><?php echo e($d->chat); ?></p>
                            <?php else: ?>
                                <p><img width="150px" src="<?php echo e(url('/image/'.$d->product_id)); ?>" alt=""></p>
                                <p><?php echo e($d->chat); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="box-footer text-right">
                            <p><?php echo e($d->date); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="margin: auto" class="row">
        <?php if($chat->user_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
            <?php $tem = $chat->seller_id ?>
        <?php else: ?>
            <?php $tem = $chat->user_id ?>
        <?php endif; ?>
        
            <input type="text" style="width: 92.6%" id="chat" name="chat">
            <button type="button" onclick="insert(<?php echo e($chat->id); ?>,<?php echo e($tem); ?>)" class="btn btn-primary btn-sm">Send</button>
        
    </div>
</body>
<script>
    function insert(id,ids) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url : "/chat_detail/"+id+"/"+ids,
            type : "POST",
            data : {
                name : $('#chat').val(),
            },
            cache : false,
            success: function () {
                location.reload();
            }
        });
    }
</script>
</html>