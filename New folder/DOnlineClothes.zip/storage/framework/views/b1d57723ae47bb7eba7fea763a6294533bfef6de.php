<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h3 class="text-center">Clothes</h3>
        <br>
        <div class="text-center">
            <form action="<?php echo e(route('search_product')); ?>" method="POST" style="width: 50%;" class="col-md-offset-3">
                <?php echo e(csrf_field()); ?>

                <div class="input-group">
                    <input type="text" name="search_string" id="search_string" placeholder="Search"
                        class="form-control">
                    <div class="input-group-btn">
                        <input type="submit" name="search_button" id="search_button" value="Search" class="btn btn-primary">
                    </div>
                </div>
            </form>
        </div>
        <br>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="thumbnail text-center">
                <p><img src="<?php echo e(Storage::url($product->image)); ?>" width="150px" alt="Product Image"></p>
                <h5><?php echo e($product->name); ?></h5>
                <p><?php echo e($product->category->name); ?></p>
                <p><?php echo e($product->price); ?></p>
                <p><?php echo e($product->stock); ?></p>
                <p><?php echo e($product->description); ?></p>

                <?php if(Auth::user()['role'] == 'Member'): ?>
                <form action="<?php echo e(route('add_to_cart', $product)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                </form>
                <?php elseif(Auth::user()['role'] == 'Admin'): ?>
                <a href="<?php echo e(route('edit_product', $product)); ?>" class="btn btn-primary">Edit</a>
                <form action="<?php echo e(route('delete_product', $product)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>


                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="text-center"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>