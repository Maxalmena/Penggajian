<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="box">
                <div class="box-header">
                    <h2>Notification</h2>
                </div>
                <div class="box-body">
                    <div class="row">
                        <?php $__currentLoopData = $notiff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="width: 97%;margin: auto" class="box">
                                <div class="box-header">
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($n->buyer_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                            <?php if($n->seller_id == $u->id): ?>
                                                <h3 style="margin-left: 15px"><?php echo e($n->name); ?></h3>
                                            <?php endif; ?>
                                        <?php elseif($n->seller_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                            <?php if($n->buyer_id == $u->id): ?>
                                                <h3 style="margin-left: 15px"><?php echo e($u->name); ?></h3>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="box-body">
                                    <div class="col-md-4">
                                        <?php if($n->active == 2 && \Illuminate\Support\Facades\Auth::user()['id'] == 2): ?>
                                            <img src="<?php echo e(url('/image/'.$n->bukti)); ?>" height="160px">
                                        <?php else: ?>
                                            <img src="<?php echo e(url('/image/'.$n->image)); ?>" height="160px">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($n->seller_id == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                            <p style="font-size: 25px">Nama   : <?php echo e($n->name); ?></p>
                                        <?php endif; ?>
                                        <p style="font-size: 25px">Harga  : <?php echo e($n->total_amount_plus_fee); ?></p>
                                        <?php $__currentLoopData = $quantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($n->transaction_id == $q->transaction_id && $n->product_id == $q->product_id): ?>
                                                <p style="font-size: 25px">Jumlah : <?php echo e($q->quantity); ?></p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="box-footer text-right">
                                    <?php if($n->active == \Illuminate\Support\Facades\Auth::user()['id'] && $n->seller_id == \Illuminate\Support\Facades\Auth::user()['id']&& $n->struktur == 3): ?>
                                        <form action="/finish_notif/<?php echo e($n->id); ?>/<?php echo e($n->buyer_id); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button class="btn btn-primary">Selesaikan</button>
                                        </form>
                                    <?php elseif($n->active == \Illuminate\Support\Facades\Auth::user()['id'] && $n->buyer_id == \Illuminate\Support\Facades\Auth::user()['id'] && $n->struktur == 4): ?>
                                        <a href="/ulasan/<?php echo e($n->product_id); ?>">
                                            <button class="btn btn-primary">Ulasan & Rating</button>
                                        </a>
                                    <?php elseif($n->active == \Illuminate\Support\Facades\Auth::user()['id'] && $n->buyer_id == \Illuminate\Support\Facades\Auth::user()['id'] && $n->struktur == 1): ?>
                                        <form class="form-horizontal" method="POST" action="<?php echo e(route('bukti' , $n->id)); ?>" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <label class="pull-left">Post Payment : </label><input type="file" name="image" id="image">
                                            <button class="btn btn-primary">Post</button>
                                        </form>
                                    <?php elseif($n->struktur == 2  && $n->active == \Illuminate\Support\Facades\Auth::user()['id']): ?>
                                        <form action="/process/<?php echo e($n->id); ?>/<?php echo e($n->seller_id); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button class="btn btn-primary">Process to Seller</button>
                                        </form>
                                    <?php elseif($n->active != \Illuminate\Support\Facades\Auth::user()['id'] && $n->active != 0): ?>
                                        <h3>On Process</h3>
                                    <?php else: ?>
                                        <h3>Selesai</h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>